const Reserva = require('../../models/reservas/reservas');
const { body, validationResult } = require('express-validator');

async function crearReserva(req, res){
    try {
        await body('id_usu').notEmpty().withMessage('El campo "id_usu" es requerido').run(req);
        await body('fecha_check_in').notEmpty().withMessage('El campo "fecha_check_in" es requerido').run(req);
        await body('fecha_check_out').notEmpty().withMessage('El campo "fecha_check_out" es requerido').run(req);

        const errors = validationResult(req);
        if (!errors.isEmpty()) { 
            return res.status(400).json({
                status: '400 BAD REQUEST',
                message: 'API: Errores de validación',
                errors: errors.array()
            });
        }

        const reserva = new Reserva(req.body);
        await reserva.save();
        res.status(201).send(reserva);
    } catch (err) {
        res.status(400).send(err);
    }
}

async function modificarReserva(req, res){
    
}

async function eliminarReserva(req, res){
    
}

module.exports = {
    crearReserva,
    modificarReserva,
    eliminarReserva,
}